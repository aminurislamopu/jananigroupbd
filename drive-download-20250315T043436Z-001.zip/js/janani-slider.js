jQuery(document).ready(function($) {

    /**
     * Sister Concern Slider
     */
    $('#home-page-slider').flexslider({
        animation: "fade",
        controlNav: false,
        pauseOnHover: true
    });


});